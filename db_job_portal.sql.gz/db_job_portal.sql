-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 17, 2024 at 07:43 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_job_portal`
--

-- --------------------------------------------------------

--
-- Table structure for table `applications`
--

CREATE TABLE `applications` (
  `application_id` varchar(50) NOT NULL,
  `listing_id` varchar(50) NOT NULL,
  `applicant_id` varchar(50) NOT NULL,
  `host_id` varchar(50) NOT NULL,
  `status` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `applications`
--

INSERT INTO `applications` (`application_id`, `listing_id`, `applicant_id`, `host_id`, `status`) VALUES
('AP65f68fb8a64e620240317073744', 'L65f68e5d6cb1320240317073157', '65f682551302d20240317064037', '65f6810657e1e20240317063502', 'Rejected'),
('AP65f68fbb2579020240317073747', 'L65f68e8721cc620240317073239', '65f682551302d20240317064037', '65f6810657e1e20240317063502', 'Accepted'),
('AP65f68fbbdd42120240317073747', 'L65f68f1c13e8920240317073508', '65f682551302d20240317064037', '65f68eee670fe20240317073422', 'Accepted');

-- --------------------------------------------------------

--
-- Table structure for table `job_listings`
--

CREATE TABLE `job_listings` (
  `listing_id` varchar(30) NOT NULL,
  `user_id` varchar(30) NOT NULL,
  `company_name` varchar(100) NOT NULL,
  `company_logo` varchar(5000) NOT NULL,
  `role` varchar(50) NOT NULL,
  `salary` varchar(10000) NOT NULL,
  `work_location` varchar(1000) NOT NULL,
  `date` date NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `job_listings`
--

INSERT INTO `job_listings` (`listing_id`, `user_id`, `company_name`, `company_logo`, `role`, `salary`, `work_location`, `date`) VALUES
('L65f68e5d6cb1320240317073157', '65f6810657e1e20240317063502', 'company1', 'IMG65f68e5d6cb5a20240317073157.jpg', 'manager', '90', 'kolkata', '2024-03-17'),
('L65f68e8721cc620240317073239', '65f6810657e1e20240317063502', 'company2', 'IMG65f68e8721d3e20240317073239.jpg', 'engineer', '50', 'mumbai', '2024-03-17'),
('L65f68f1c13e8920240317073508', '65f68eee670fe20240317073422', 'comapany3', 'IMG65f68f1c13ede20240317073508.jpg', 'developer', '50', 'delhi', '2024-03-17');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` varchar(30) NOT NULL,
  `user_name` varchar(20) NOT NULL,
  `account_type` varchar(10) NOT NULL,
  `full_name` varchar(1000) NOT NULL,
  `password` varchar(20) NOT NULL,
  `profile_pic` varchar(1000) NOT NULL,
  `bio` varchar(2000) NOT NULL,
  `skills` varchar(1000) NOT NULL,
  `interests` varchar(1000) NOT NULL,
  `contact_num` varchar(10) NOT NULL,
  `city` varchar(100) NOT NULL,
  `email` varchar(260) NOT NULL,
  `resume` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `user_name`, `account_type`, `full_name`, `password`, `profile_pic`, `bio`, `skills`, `interests`, `contact_num`, `city`, `email`, `resume`) VALUES
('65f6810657e1e20240317063502', 'user@01', 'provider', 'user01', 'hello@01', 'IMG65f6810657e6120240317063502.png', '', 'graphic-design', 'time-management', '123456789', 'Diamond Harbour', 'user01@gmail.com', 'IMG65f68106584dc20240317063502.jpg'),
('65f682551302d20240317064037', 'user@02', 'seeker', 'user02', 'hello@01', 'IMG65f682551309420240317064037.png', 'hello i need job ', 'communication', 'data-analysis', '876428643', 'Gosaba', 'user02@gmail.com', 'IMG65f682551390d20240317064037.jpg'),
('65f68eee670fe20240317073422', 'user@03', 'provider', 'user03', 'hello@01', 'IMG65f68eee6715020240317073422.png', '', 'teamwork', 'graphic-design', '765247654', 'Bagnan', 'user03@gmail.com', 'IMG65f68eee67c6f20240317073422.jpg');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `applications`
--
ALTER TABLE `applications`
  ADD PRIMARY KEY (`application_id`);

--
-- Indexes for table `job_listings`
--
ALTER TABLE `job_listings`
  ADD PRIMARY KEY (`listing_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `UNIQUE1` (`user_name`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
